package com.example.puc_minas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
