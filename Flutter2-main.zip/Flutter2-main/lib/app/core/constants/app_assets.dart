class AppAssets {
  static String get logo => 'assets/images/logo.png';

}