class AppRoutes {
  static  String splash ='/';
  static String home = '/home';
  static String login = 'login';
}